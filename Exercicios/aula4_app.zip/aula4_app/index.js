var express = require('express')
var app = express()
var calc = require('./calculadora')

app.get('/', function(req, res){
    res.send('Olá, mundo!')
})

app.get('/somar/:n1/:n2', function(req, res){
    let soma = calc.somar(parseInt(req.params.n1), parseInt(req.params.n2))
    res.send('Soma de '+req.params.n1+' e '+req.params.n2+' = ' + soma)
})

app.get('/subtrair/:n1/:n2', function(req, res){
    let sub = calc.subtrair(req.params.n1, req.params.n2)
    res.send('Subtração de '+req.params.n1+' e '+req.params.n2+' = ' + sub)
})

app.get('/multiplicar/:n1/:n2', function(req, res){
    let mult = calc.multiplicar(req.params.n1, req.params.n2)
    res.send('Multiplicação de '+req.params.n1+' e '+req.params.n2+' = ' + mult)
})

app.get('/dividir/:n1/:n2', function(req, res){
    let div = calc.dividir(req.params.n1, req.params.n2)
    res.send('Divisão de '+req.params.n1+' e '+req.params.n2+' = ' + div)
})

app.get('/fatorar/:n', function(req, res){
    let fat = calc.fatorial(req.params.n)
    res.send('Fatorial de '+req.params.n+' = ' + fat)
})

app.listen(8000, function(){
    console.log('app rodando na porta http://127.0.0.1:8000')
})

